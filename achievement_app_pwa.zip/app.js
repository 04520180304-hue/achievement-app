
import App from './react_app.js';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));
